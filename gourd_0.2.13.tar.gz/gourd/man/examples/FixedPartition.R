FixedPartition(anchor=c(1,1,1,2,2))
