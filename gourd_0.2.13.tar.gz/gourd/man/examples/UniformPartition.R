UniformPartition(nItems=5)
